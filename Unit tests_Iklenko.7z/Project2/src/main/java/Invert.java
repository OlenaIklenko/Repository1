import java.util.Arrays;

/**
 * Created by Olena_Iklenko on 9/7/2016.
 */
public class Invert {
    public static void main (String[] args) {
// Block 1
        int index = 2;
        int [] array = {2, 3, 5, 6, 7};

        //Block 2
        GetValue getValue = new GetValue();
        int result = getValue.getValueFromIndex(index, array);

        //Block 3
        System.out.println(result);
        int res = getValue.division1(4,0);
        System.out.println(res);
    }


    }

